# Jessie P — Artist Website

A responsive artist website for Jessie P (Jessica Peter), featuring the single “wanna be”.

## Publish with GitHub Pages

1. Sign in to GitHub and create a **new public repository** named `YOUR-USERNAME.github.io` (replace `YOUR-USERNAME` with your GitHub username).
2. Upload `index.html` from this folder to the repository's root.
3. Open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select **main** and **/(root)**, then save.
4. Wait for deployment. Your site address will be `https://YOUR-USERNAME.github.io/`.
5. To help Google discover it, add the live URL to Google Search Console and request indexing.

Google indexing is not immediate or guaranteed. A website being online does not guarantee it will rank first for a name.
